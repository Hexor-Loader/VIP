package com.hexoradmin;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.MediaMetadataRetriever;
import android.net.*;
import android.util.Base64;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class MainActivity extends Activity {

    private static final String OWNER = "Hexor-Loader";
    private static final String REPO = "VIP";
    private static final String BRANCH = "main";
    private static final String API_BASE = "https://api.github.com/repos/" + OWNER + "/" + REPO + "/contents/";
    private static final String RAW_BASE = "https://raw.githubusercontent.com/" + OWNER + "/" + REPO + "/refs/heads/" + BRANCH + "/";
    private static final int PICK_FILE_REQUEST = 7001;

    private LinearLayout root, content;
    private TextView titleView, pathView;
    private EditText tokenInput;
    private ProgressBar progress;
    private String token = "";
    private String currentPath = "";
    private final Stack<String> backStack = new Stack<>();
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final ArrayList<GitFile> currentFiles = new ArrayList<>();

    private final int bg = Color.rgb(7, 10, 18);
    private final int card = Color.rgb(17, 23, 38);
    private final int accent = Color.rgb(0, 214, 255);
    private final int accent2 = Color.rgb(124, 58, 237);
    private final int sub = Color.rgb(170, 180, 205);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        token = getPreferences(0).getString("github_token", "");
        buildUi();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(14), dp(12), dp(10));
        root.setBackground(makeGradient(bg, Color.rgb(10, 17, 32)));
        setContentView(root);

        LinearLayout logoCard = panel(18);
        logoCard.setGravity(Gravity.CENTER);
        logoCard.setPadding(dp(12), dp(8), dp(12), dp(8));
        root.addView(logoCard, mp(-1, dp(52), 0, 0, 0, 8));

        LinearLayout logoRow = new LinearLayout(this);
        logoRow.setOrientation(LinearLayout.HORIZONTAL);
        logoRow.setGravity(Gravity.CENTER);

        TextView hexor = tv("HEXOR", 18, Color.WHITE, true);
        TextView space = tv("  ", 18, Color.WHITE, false);
        TextView admin = tv("ADMIN", 18, Color.rgb(255, 205, 45), true);
        logoRow.addView(hexor);
        logoRow.addView(space);
        logoRow.addView(admin);
        logoCard.addView(logoRow, mp(-1, -1, 0, 0, 0, 0));

        LinearLayout tokenBox = panel(16);
        tokenBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.addView(tokenBox, mp(-1, -2, 0, 0, 0, 8));

        LinearLayout tokenHeader = new LinearLayout(this);
        tokenHeader.setOrientation(LinearLayout.HORIZONTAL);
        tokenHeader.setGravity(Gravity.CENTER_VERTICAL);
        tokenHeader.addView(tv("GitHub", 13, Color.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        tokenHeader.addView(tv(OWNER + "/" + REPO, 9, sub, false));
        tokenBox.addView(tokenHeader, mp(-1, -2, 0, 0, 0, 6));

        LinearLayout tokenRow = new LinearLayout(this);
        tokenRow.setOrientation(LinearLayout.HORIZONTAL);
        tokenRow.setGravity(Gravity.CENTER_VERTICAL);

        tokenInput = new EditText(this);
        tokenInput.setSingleLine(true);
        tokenInput.setText(token);
        tokenInput.setHint("github_pat_...");
        tokenInput.setTextSize(11);
        tokenInput.setTextColor(Color.WHITE);
        tokenInput.setHintTextColor(Color.rgb(120,130,155));
        tokenInput.setBackground(fieldBg());
        tokenInput.setPadding(dp(10), 0, dp(10), 0);
        tokenRow.addView(tokenInput, new LinearLayout.LayoutParams(0, dp(38), 1));

        tokenRow.addView(miniBtn("حفظ", accent, () -> {
            token = tokenInput.getText().toString().trim();
            getPreferences(0).edit().putString("github_token", token).apply();
            toast("تم حفظ الرمز");
            hideKeyboard();
            loadPath(currentPath);
        }), mp(dp(58), dp(38), 6, 0, 0, 0));

        tokenRow.addView(miniBtn("إخفاء", Color.rgb(48,58,82), () -> {
            tokenInput.setText("");
            toast("تم إخفاء الرمز من الشاشة فقط");
        }), mp(dp(62), dp(38), 5, 0, 0, 0));

        tokenBox.addView(tokenRow);

        LinearLayout browser = panel(18);
        browser.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));

        titleView = tv("مدير الملفات", 18, Color.WHITE, true);
        titleView.setGravity(Gravity.RIGHT);
        browser.addView(titleView);

        pathView = tv("/", 12, sub, false);
        pathView.setGravity(Gravity.RIGHT);
        browser.addView(pathView, mp(-1, -2, 0, 3, 0, 8));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setWeightSum(4);

        nav.addView(navBtn("رجوع", Color.rgb(48,58,82), this::goBack));
        nav.addView(navBtn("تحديث", accent2, () -> loadPath(currentPath)));
        nav.addView(navBtn("رفع هنا", accent, this::pickFile));
        nav.addView(navBtn("إنشاء", Color.rgb(32, 190, 130), this::showCreateFileDialog));

        browser.addView(nav, mp(-1, dp(40), 0, 0, 0, 8));

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        browser.addView(progress, mp(-1, dp(30), 0, 0, 0, 6));

        ScrollView filesScroll = new ScrollView(this);
        filesScroll.setFillViewport(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        filesScroll.addView(content);
        browser.addView(filesScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        showEmpty("أدخل الرمز ثم اضغط حفظ");
        if (token.length() > 0) loadPath("");
    }

    private TextView miniBtn(String s, int color, Runnable r) {
        TextView b = tv(s, 12, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setBackground(round(color, 13));
        b.setOnClickListener(v -> r.run());
        return b;
    }

    private TextView navBtn(String s, int color, Runnable r) {
        TextView b = tv(s, 10, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setBackground(round(color, 12));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1);
        lp.setMargins(dp(2), dp(3), dp(2), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private TextView statCard(String a, String b) {
        TextView v = tv(a + "\n" + b, 12, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(round(Color.rgb(28,36,58), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(72), 1);
        lp.setMargins(dp(4), dp(8), dp(4), 0);
        v.setLayoutParams(lp);
        return v;
    }

    private View tile(String icon, String name, String desc, final Runnable click) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setBackground(roundStroke(Color.rgb(20, 28, 46), 18, Color.rgb(45, 58, 90)));
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = (getResources().getDisplayMetrics().widthPixels - dp(64)) / 2;
        gp.height = dp(118);
        gp.setMargins(dp(4), dp(6), dp(4), dp(6));
        t.setLayoutParams(gp);
        t.addView(tv(icon, 24, Color.WHITE, false));
        t.addView(tv(name, 15, Color.WHITE, true));
        t.addView(tv(desc, 11, sub, false));
        t.setOnClickListener(v -> click.run());
        return t;
    }

    private void loadPath(String path) {
        if (token.trim().isEmpty()) {
            showEmpty("أدخل GitHub Token أولًا");
            return;
        }
        currentPath = path == null ? "" : path;
        pathView.setText("/" + currentPath);
        setLoading(true);
        executor.execute(() -> {
            try {
                String url = API_BASE + encodePath(currentPath) + "?ref=" + BRANCH;
                String res = request("GET", url, null);
                Object parsed = new JSONTokener(res).nextValue();
                ArrayList<GitFile> files = new ArrayList<>();
                if (parsed instanceof JSONArray) {
                    JSONArray arr = (JSONArray) parsed;
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        files.add(new GitFile(o.optString("name"), o.optString("path"), o.optString("type"), o.optString("sha"), o.optString("download_url")));
                    }
                    Collections.sort(files, (a,b) -> {
                        if (!a.type.equals(b.type)) return a.type.equals("dir") ? -1 : 1;
                        return a.name.compareToIgnoreCase(b.name);
                    });
                    runOnUiThread(() -> renderFiles(files));
                } else if (parsed instanceof JSONObject) {
                    openEditorFromObject((JSONObject) parsed);
                }
            } catch (Exception e) {
                runOnUiThread(() -> showEmpty("خطأ: " + e.getMessage()));
            } finally {
                runOnUiThread(() -> setLoading(false));
            }
        });
    }

    private void renderFiles(ArrayList<GitFile> files) {
        currentFiles.clear();
        currentFiles.addAll(files);
        content.removeAllViews();
        titleView.setText("مدير الملفات  •  " + files.size());
        if (files.isEmpty()) {
            showEmpty("لا توجد ملفات هنا");
            return;
        }
        for (GitFile f : files) content.addView(fileRow(f), mp(-1, -2, 0, 6, 0, 6));
    }

    private View fileRow(GitFile f) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(10), dp(8), dp(10));
        row.setBackground(round(Color.rgb(22, 30, 49), 16));

        FrameLayout thumbBox = new FrameLayout(this);
        thumbBox.setBackground(round(Color.rgb(30, 39, 62), 14));

        if (!f.type.equals("dir") && isImageFile(f.name) && f.downloadUrl != null && f.downloadUrl.length() > 0) {
            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setBackground(round(Color.rgb(30, 39, 62), 14));
            thumbBox.addView(thumb, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));
            TextView loading = tv("⌛", 18, sub, true);
            loading.setGravity(Gravity.CENTER);
            thumbBox.addView(loading, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));
            loadImage(thumb, f.downloadUrl, loading);
        } else if (!f.type.equals("dir") && isVideoFile(f.name) && f.downloadUrl != null && f.downloadUrl.length() > 0) {
            ImageView thumb = new ImageView(this);
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setBackground(round(Color.rgb(30, 39, 62), 14));
            thumbBox.addView(thumb, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));

            TextView loading = tv("⌛", 16, sub, true);
            loading.setGravity(Gravity.CENTER);
            thumbBox.addView(loading, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));

            TextView play = tv("▶", 24, Color.WHITE, true);
            play.setGravity(Gravity.CENTER);
            play.setBackground(round(Color.argb(135, 0, 0, 0), 100));
            thumbBox.addView(play, new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));

            loadVideoThumbnail(thumb, f.downloadUrl, loading);
        } else {
            TextView icon = tv(f.type.equals("dir") ? "📁" : iconFor(f.name), 25, Color.WHITE, false);
            icon.setGravity(Gravity.CENTER);
            thumbBox.addView(icon, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));
        }

        row.addView(thumbBox, mp(dp(58), dp(58), 0, 0, 10, 0));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(tv(f.name, 14, Color.WHITE, true));
        mid.addView(tv(f.path, 11, sub, false));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1));

        TextView more = tv("⋮", 26, sub, true);
        more.setGravity(Gravity.CENTER);
        row.addView(more, mp(dp(34), dp(42), 0, 0, 0, 0));

        row.setOnClickListener(v -> {
            if (f.type.equals("dir")) {
                backStack.push(currentPath);
                loadPath(f.path);
            } else openFile(f);
        });
        more.setOnClickListener(v -> showFileActions(f));
        return row;
    }

    private boolean isImageFile(String name) {
        String n = name.toLowerCase(Locale.US);
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp");
    }

    private boolean isVideoFile(String name) {
        String n = name.toLowerCase(Locale.US);
        return n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".webm") || n.endsWith(".mov") || n.endsWith(".m3u8");
    }

    private String iconFor(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.endsWith(".json")) return "🧩";
        if (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")) return "🖼";
        if (n.endsWith(".mp4") || n.endsWith(".m3u8") || n.endsWith(".mkv") || n.endsWith(".webm") || n.endsWith(".mov")) return "🎥";
        if (n.endsWith(".m3u")) return "📺";
        if (n.endsWith(".apk")) return "📦";
        return "📄";
    }

    private void openFile(GitFile f) {
        String n = f.name.toLowerCase(Locale.US);
        if (isImageFile(f.name)) showImagePreview(f);
        else if (isVideoFile(f.name)) showVideoPlayer(f);
        else if (n.endsWith(".json")) showJsonEditOptions(f);
        else if (n.endsWith(".txt") || n.endsWith(".m3u") || n.endsWith(".xml") || n.endsWith(".html") || n.endsWith(".css") || n.endsWith(".js")) loadFileForEdit(f.path);
        else showFileActions(f);
    }

    private void showJsonEditOptions(GitFile f) {
        final Dialog d = new Dialog(this);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackground(round(Color.rgb(10, 15, 28), 22));

        box.addView(tv("خيارات تعديل JSON", 16, Color.WHITE, true));
        box.addView(tv(f.path, 10, sub, false), mp(-1, -2, 0, 2, 0, 10));

        box.addView(actionRow("تعديل JSON كامل", "فتح الملف كاملًا وتعديل الكود", "{}", accent2, () -> {
            d.dismiss();
            loadFileForEdit(f.path);
        }));

        box.addView(actionRow("تعديل الحقول فقط", "تعديل النصوص والروابط والوقت واليوم بسهولة", "✎", accent, () -> {
            d.dismiss();
            loadJsonForFields(f.path);
        }));

        d.setContentView(box);
        d.show();
        applyMediumDialog(d, 0.84f);
    }

    private void loadJsonForFields(String path) {
        setLoading(true);
        executor.execute(() -> {
            try {
                String res = request("GET", API_BASE + encodePath(path) + "?ref=" + BRANCH, null);
                JSONObject o = new JSONObject(res);
                String sha = o.optString("sha");
                String content64 = o.optString("content", "").replace("\n", "");
                String decoded = new String(Base64.decode(content64, Base64.DEFAULT), StandardCharsets.UTF_8);
                runOnUiThread(() -> showJsonFieldsEditor(path, sha, decoded));
            } catch(Exception e) {
                runOnUiThread(() -> toast("خطأ فتح الحقول: " + e.getMessage()));
            } finally {
                runOnUiThread(() -> setLoading(false));
            }
        });
    }

    private void showJsonFieldsEditor(String path, String sha, String jsonText) {
        try {
            Object parsed = new JSONTokener(jsonText).nextValue();
            if (!(parsed instanceof JSONObject) && !(parsed instanceof JSONArray)) {
                toast("هذا الملف ليس JSON مناسبًا للحقول");
                return;
            }

            final ArrayList<JsonField> fields = new ArrayList<>();
            collectJsonFields(parsed, "", fields);

            if (fields.isEmpty()) {
                toast("لا توجد حقول نصية قابلة للتعديل");
                return;
            }

            final Dialog d = new Dialog(this);

            LinearLayout outer = new LinearLayout(this);
            outer.setOrientation(LinearLayout.VERTICAL);
            outer.setPadding(dp(10), dp(10), dp(10), dp(10));
            outer.setBackground(round(Color.rgb(10, 15, 28), 22));

            outer.addView(tv("تعديل الحقول", 16, Color.WHITE, true));
            outer.addView(tv(path, 10, sub, false), mp(-1, -2, 0, 2, 0, 8));

            ScrollView scroll = new ScrollView(this);
            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            scroll.addView(list);

            for (JsonField field : fields) {
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setPadding(dp(10), dp(8), dp(10), dp(8));
                item.setBackground(round(Color.rgb(18, 26, 44), 14));

                TextView label = tv(friendlyJsonLabel(field.key), 12, Color.WHITE, true);
                TextView key = tv(field.path, 9, sub, false);

                EditText value = new EditText(this);
                value.setSingleLine(false);
                value.setText(String.valueOf(field.value));
                value.setTextSize(11);
                value.setTextColor(Color.WHITE);
                value.setHintTextColor(sub);
                value.setBackground(fieldBg());
                value.setPadding(dp(8), dp(6), dp(8), dp(6));
                value.setMinLines(field.value != null && String.valueOf(field.value).length() > 55 ? 2 : 1);

                field.editor = value;

                item.addView(label);
                item.addView(key, mp(-1, -2, 0, 1, 0, 5));
                item.addView(value, mp(-1, dp(field.value != null && String.valueOf(field.value).length() > 55 ? 68 : 42), 0, 0, 0, 0));

                LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
                itemLp.setMargins(0, 0, 0, dp(8));
                list.addView(item, itemLp);
            }

            outer.addView(scroll, mp(-1, dp(360), 0, 0, 0, 10));

            LinearLayout actions = row();

            actions.addView(dialogBtn("حفظ الحقول", accent, () -> {
                try {
                    for (JsonField field : fields) {
                        Object newValue = convertJsonValue(field.editor.getText().toString(), field.originalType);
                        setJsonValue(parsed, field.tokens, newValue);
                    }

                    String output;
                    if (parsed instanceof JSONObject) output = ((JSONObject) parsed).toString(2);
                    else output = ((JSONArray) parsed).toString(2);

                    saveTextFile(path, sha, output, () -> {
                        d.dismiss();
                        loadPath(parentOf(path));
                    });
                } catch(Exception e) {
                    toast("فشل حفظ الحقول: " + e.getMessage());
                }
            }));

            actions.addView(dialogBtn("إلغاء", Color.rgb(56, 66, 94), () -> d.dismiss()));

            outer.addView(actions);

            d.setContentView(outer);
            d.show();
            applyMediumDialog(d, 0.90f);

        } catch(Exception e) {
            toast("JSON غير صحيح");
        }
    }

    private void collectJsonFields(Object node, String path, ArrayList<JsonField> out) throws Exception {
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                Object v = obj.get(k);
                String p = path.length() == 0 ? k : path + "." + k;
                if (v instanceof JSONObject || v instanceof JSONArray) {
                    collectJsonFields(v, p, out);
                } else if (isEditableJsonValue(v)) {
                    out.add(new JsonField(k, p, v, jsonTokensFromPath(p)));
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                Object v = arr.get(i);
                String p = path + "[" + i + "]";
                if (v instanceof JSONObject || v instanceof JSONArray) {
                    collectJsonFields(v, p, out);
                } else if (isEditableJsonValue(v)) {
                    out.add(new JsonField("item " + (i + 1), p, v, jsonTokensFromPath(p)));
                }
            }
        }
    }

    private boolean isEditableJsonValue(Object v) {
        return v == JSONObject.NULL || v instanceof String || v instanceof Number || v instanceof Boolean;
    }

    private Object convertJsonValue(String s, String type) {
        try {
            if ("boolean".equals(type)) return "true".equalsIgnoreCase(s) || "1".equals(s);
            if ("integer".equals(type)) return Integer.parseInt(s.trim());
            if ("long".equals(type)) return Long.parseLong(s.trim());
            if ("double".equals(type)) return Double.parseDouble(s.trim());
            if ("null".equals(type)) return s.length() == 0 ? JSONObject.NULL : s;
        } catch(Exception ignored) {}
        return s;
    }

    private ArrayList<Object> jsonTokensFromPath(String path) {
        ArrayList<Object> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '.') {
                if (current.length() > 0) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
            } else if (c == '[') {
                if (current.length() > 0) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
                int end = path.indexOf(']', i);
                if (end > i) {
                    tokens.add(Integer.parseInt(path.substring(i + 1, end)));
                    i = end;
                }
            } else {
                current.append(c);
            }
        }
        if (current.length() > 0) tokens.add(current.toString());
        return tokens;
    }

    private void setJsonValue(Object rootNode, ArrayList<Object> tokens, Object value) throws Exception {
        Object current = rootNode;
        for (int i = 0; i < tokens.size() - 1; i++) {
            Object t = tokens.get(i);
            if (t instanceof Integer) current = ((JSONArray) current).get((Integer) t);
            else current = ((JSONObject) current).get((String) t);
        }

        Object last = tokens.get(tokens.size() - 1);
        if (last instanceof Integer) ((JSONArray) current).put((Integer) last, value);
        else ((JSONObject) current).put((String) last, value);
    }

    private String friendlyJsonLabel(String key) {
        String k = key == null ? "" : key.toLowerCase(Locale.US);
        if (k.contains("title") || k.contains("name")) return "الاسم / العنوان";
        if (k.contains("url") || k.contains("link")) return "الرابط";
        if (k.contains("image") || k.contains("thumb")) return "الصورة";
        if (k.contains("video")) return "الفيديو";
        if (k.contains("time")) return "الوقت";
        if (k.contains("day")) return "اليوم";
        if (k.contains("date")) return "التاريخ";
        if (k.contains("id")) return "المعرّف";
        if (k.contains("type")) return "النوع";
        return key;
    }

    static class JsonField {
        String key;
        String path;
        Object value;
        String originalType;
        ArrayList<Object> tokens;
        EditText editor;

        JsonField(String key, String path, Object value, ArrayList<Object> tokens) {
            this.key = key;
            this.path = path;
            this.value = value;
            this.tokens = tokens;
            if (value == JSONObject.NULL) originalType = "null";
            else if (value instanceof Integer) originalType = "integer";
            else if (value instanceof Long) originalType = "long";
            else if (value instanceof Float || value instanceof Double) originalType = "double";
            else if (value instanceof Number) originalType = "double";
            else if (value instanceof Boolean) originalType = "boolean";
            else originalType = "string";
        }
    }

    private void loadFileForEdit(String path) {
        setLoading(true);
        executor.execute(() -> {
            try {
                String res = request("GET", API_BASE + encodePath(path) + "?ref=" + BRANCH, null);
                openEditorFromObject(new JSONObject(res));
            } catch(Exception e) {
                runOnUiThread(() -> toast("خطأ فتح الملف: " + e.getMessage()));
            } finally {
                runOnUiThread(() -> setLoading(false));
            }
        });
    }

    private void openEditorFromObject(JSONObject o) {
        try {
            String path = o.optString("path");
            String sha = o.optString("sha");
            String content64 = o.optString("content", "").replace("\n", "");
            String decoded = new String(Base64.decode(content64, Base64.DEFAULT), StandardCharsets.UTF_8);
            runOnUiThread(() -> showEditor(path, sha, decoded));
        } catch(Exception e) {
            runOnUiThread(() -> toast("تعذر قراءة الملف"));
        }
    }

    private void showEditor(String path, String sha, String value) {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackground(round(Color.rgb(12, 18, 32), 22));

        box.addView(tv("تعديل الملف", 16, Color.WHITE, true));
        box.addView(tv(path, 11, sub, false), mp(-1, -2, 0, 2, 0, 8));

        EditText editor = new EditText(this);
        editor.setMinLines(10);
        editor.setGravity(Gravity.TOP | Gravity.RIGHT);
        editor.setText(value);
        editor.setTextColor(Color.WHITE);
        editor.setHintTextColor(sub);
        editor.setTextSize(12);
        editor.setBackground(fieldBg());
        editor.setPadding(dp(10), dp(10), dp(10), dp(10));
        box.addView(editor, mp(-1, dp(270), 0, 0, 0, 10));

        LinearLayout buttons = row();
        buttons.addView(dialogBtn("حفظ", accent, () -> saveTextFile(path, sha, editor.getText().toString(), () -> {
            d.dismiss();
            loadPath(parentOf(path));
        })));
        buttons.addView(dialogBtn("تنسيق JSON", accent2, () -> {
            try {
                Object parsed = new JSONTokener(editor.getText().toString()).nextValue();
                if (parsed instanceof JSONObject) editor.setText(((JSONObject) parsed).toString(2));
                else if (parsed instanceof JSONArray) editor.setText(((JSONArray) parsed).toString(2));
                toast("تم تنسيق JSON");
            } catch(Exception e) {
                toast("JSON غير صحيح");
            }
        }));
        box.addView(buttons);

        d.setContentView(box);
        d.show();
        applyMediumDialog(d, 0.88f);
    }

    private void saveTextFile(String path, String sha, String newText, Runnable done) {
        setLoading(true);
        executor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("message", "Update " + path + " from Hexor Admin");
                body.put("content", Base64.encodeToString(newText.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP));
                body.put("branch", BRANCH);
                if (sha != null && sha.length() > 0) body.put("sha", sha);
                request("PUT", API_BASE + encodePath(path), body.toString());
                runOnUiThread(() -> {
                    toast("تم الحفظ في GitHub");
                    if (done != null) done.run();
                });
            } catch(Exception e) {
                runOnUiThread(() -> toast("فشل الحفظ: " + e.getMessage()));
            } finally {
                runOnUiThread(() -> setLoading(false));
            }
        });
    }

    private void showImagePreview(GitFile f) {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(round(Color.rgb(12, 18, 32), 22));
        box.addView(tv("معاينة الصورة", 16, Color.WHITE, true));
        box.addView(tv(f.path, 11, sub, false), mp(-1, -2, 0, 2, 0, 8));
        ImageView img = new ImageView(this);
        img.setBackground(round(Color.rgb(20, 28, 46), 16));
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        box.addView(img, mp(-1, dp(240), 0, 8, 0, 10));
        loadImage(img, f.downloadUrl);
        LinearLayout actions = row();
        actions.addView(dialogBtn("نسخ الرابط", accent2, () -> {
            copy(RAW_BASE + f.path);
            toast("تم نسخ الرابط");
        }));
        actions.addView(dialogBtn("حذف", Color.rgb(220, 55, 80), () -> {
            d.dismiss();
            deleteFile(f);
        }));
        box.addView(actions);
        d.setContentView(box);
        d.show();
        applyMediumDialog(d, 0.84f);
    }

    private void loadImage(ImageView img, String url) {
        loadImage(img, url, null);
    }

    private void loadImage(ImageView img, String url, View loadingView) {
        executor.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
                c.setUseCaches(true);
                c.setConnectTimeout(12000);
                c.setReadTimeout(20000);
                Bitmap b = BitmapFactory.decodeStream(c.getInputStream());
                runOnUiThread(() -> {
                    img.setImageBitmap(b);
                    if (loadingView != null) loadingView.setVisibility(View.GONE);
                });
            } catch(Exception ignored) {
                runOnUiThread(() -> {
                    if (loadingView instanceof TextView) ((TextView) loadingView).setText("🖼");
                });
            }
        });
    }

    private void loadVideoThumbnail(ImageView img, String url, View loadingView) {
        executor.execute(() -> {
            MediaMetadataRetriever retriever = null;
            try {
                retriever = new MediaMetadataRetriever();
                HashMap<String, String> headers = new HashMap<>();
                retriever.setDataSource(url, headers);
                Bitmap b = retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                runOnUiThread(() -> {
                    if (b != null) img.setImageBitmap(b);
                    if (loadingView != null) loadingView.setVisibility(View.GONE);
                });
            } catch(Exception ignored) {
                runOnUiThread(() -> {
                    if (loadingView instanceof TextView) ((TextView) loadingView).setText("🎥");
                });
            } finally {
                try {
                    if (retriever != null) retriever.release();
                } catch(Exception ignored) {}
            }
        });
    }

    private void showVideoPlayer(GitFile f) {
        final Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackground(round(Color.rgb(12, 18, 32), 22));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv("تشغيل الفيديو", 16, Color.WHITE, true));
        info.addView(tv(f.path, 10, sub, false));
        top.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        TextView close = tv("✕", 16, Color.WHITE, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(round(Color.rgb(48,58,82), 100));
        top.addView(close, mp(dp(34), dp(34), 6, 0, 0, 0));
        box.addView(top);

        FrameLayout playerBox = new FrameLayout(this);
        playerBox.setBackground(round(Color.BLACK, 16));

        VideoView video = new VideoView(this);
        video.setBackgroundColor(Color.BLACK);
        playerBox.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        ProgressBar loading = new ProgressBar(this);
        playerBox.addView(loading, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));

        box.addView(playerBox, mp(-1, dp(230), 0, 10, 0, 10));

        LinearLayout actions = row();
        actions.addView(dialogBtn("تشغيل", accent, () -> video.start()));
        actions.addView(dialogBtn("إيقاف", accent2, () -> video.pause()));
        actions.addView(dialogBtn("نسخ الرابط", Color.rgb(48,58,82), () -> {
            copy(RAW_BASE + f.path);
            toast("تم نسخ الرابط");
        }));
        box.addView(actions);

        close.setOnClickListener(v -> {
            try { video.stopPlayback(); } catch(Exception ignored) {}
            d.dismiss();
        });

        d.setOnDismissListener(x -> {
            try { video.stopPlayback(); } catch(Exception ignored) {}
        });

        video.setOnPreparedListener(mp -> {
            loading.setVisibility(View.GONE);
            mp.setLooping(false);
            video.start();
        });

        video.setOnErrorListener((mp, what, extra) -> {
            loading.setVisibility(View.GONE);
            toast("تعذر تشغيل الفيديو");
            return true;
        });

        String url = f.downloadUrl != null && f.downloadUrl.length() > 0 ? f.downloadUrl : RAW_BASE + f.path;
        video.setVideoURI(Uri.parse(url));

        d.setContentView(box);
        d.show();
        applyMediumDialog(d, 0.86f);
    }

    private void showFileActions(GitFile f) {
        final Dialog d = new Dialog(this);

        LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setPadding(dp(12), dp(12), dp(12), dp(12));
        overlay.setBackground(round(Color.rgb(10, 15, 28), 24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(2), dp(2), dp(2), dp(8));

        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(round(Color.rgb(24, 34, 58), 16));

        if (!f.type.equals("dir") && isImageFile(f.name) && f.downloadUrl != null && f.downloadUrl.length() > 0) {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iconBox.addView(img, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER));
            TextView loading = tv("⌛", 13, sub, true);
            loading.setGravity(Gravity.CENTER);
            iconBox.addView(loading, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER));
            loadImage(img, f.downloadUrl, loading);
        } else if (!f.type.equals("dir") && isVideoFile(f.name) && f.downloadUrl != null && f.downloadUrl.length() > 0) {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iconBox.addView(img, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER));
            TextView play = tv("▶", 18, Color.WHITE, true);
            play.setGravity(Gravity.CENTER);
            play.setBackground(round(Color.argb(150, 0, 0, 0), 100));
            iconBox.addView(play, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
            loadVideoThumbnail(img, f.downloadUrl, null);
        } else {
            TextView icon = tv(f.type.equals("dir") ? "📁" : iconFor(f.name), 22, Color.WHITE, false);
            icon.setGravity(Gravity.CENTER);
            iconBox.addView(icon, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER));
        }

        header.addView(iconBox, mp(dp(54), dp(54), 0, 0, 10, 0));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(f.name, 16, Color.WHITE, true));
        TextView path = tv(f.path, 10, sub, false);
        path.setSingleLine(false);
        info.addView(path, mp(-1, -2, 0, 2, 0, 0));
        header.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        TextView close = tv("✕", 16, Color.WHITE, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(round(Color.rgb(40, 50, 76), 100));
        header.addView(close, mp(dp(34), dp(34), 6, 0, 0, 0));
        overlay.addView(header);

        View line = new View(this);
        line.setBackgroundColor(Color.rgb(38, 49, 77));
        overlay.addView(line, mp(-1, dp(1), 0, 0, 0, 10));

        overlay.addView(actionRow("فتح", "عرض الملف أو تشغيل الفيديو", "↗", accent, () -> {
            d.dismiss();
            openFile(f);
        }));

        if (f.name.toLowerCase(Locale.US).endsWith(".json")) {
            overlay.addView(actionRow("تعديل الحقول", "تعديل الأسماء والروابط والوقت بدون فتح الكود", "✎", Color.rgb(32, 190, 130), () -> {
                d.dismiss();
                loadJsonForFields(f.path);
            }));
        }

        overlay.addView(actionRow("نسخ الرابط الخام", "نسخ رابط GitHub مباشر", "🔗", accent2, () -> {
            copy(RAW_BASE + f.path);
            toast("تم نسخ الرابط");
            d.dismiss();
        }));

        overlay.addView(actionRow("استبدال الملف", "رفع ملف جديد مكان الحالي", "⇄", Color.rgb(32, 190, 130), () -> {
            getPreferences(0).edit().putString("replace_path", f.path).putString("replace_sha", f.sha).apply();
            d.dismiss();
            pickFile();
        }));

        overlay.addView(actionRow("حذف", "إزالة الملف من GitHub", "🗑", Color.rgb(220, 55, 80), () -> {
            d.dismiss();
            deleteFile(f);
        }));

        close.setOnClickListener(v -> d.dismiss());

        d.setContentView(overlay);
        d.show();
        applyMediumDialog(d, 0.84f);
    }

    private View actionRow(String title, String desc, String iconText, int iconColor, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(8), dp(10), dp(8));
        row.setBackground(round(Color.rgb(18, 26, 44), 16));

        TextView icon = tv(iconText, 17, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(iconColor, 12));
        row.addView(icon, mp(dp(38), dp(38), 0, 0, 10, 0));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.addView(tv(title, 13, Color.WHITE, true));
        mid.addView(tv(desc, 10, sub, false), mp(-1, -2, 0, 1, 0, 0));
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1));

        TextView arrow = tv("‹", 20, sub, true);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, mp(dp(22), dp(38), 6, 0, 0, 0));

        row.setOnClickListener(v -> click.run());

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(params);

        return row;
    }

    private void deleteFile(GitFile f) {
        new AlertDialog.Builder(this)
                .setTitle("حذف الملف")
                .setMessage("هل تريد حذف: " + f.name + " ؟")
                .setPositiveButton("حذف", (d,w) -> {
                    setLoading(true);
                    executor.execute(() -> {
                        try {
                            JSONObject body = new JSONObject();
                            body.put("message", "Delete " + f.path + " from Hexor Admin");
                            body.put("sha", f.sha);
                            body.put("branch", BRANCH);
                            request("DELETE", API_BASE + encodePath(f.path), body.toString());
                            runOnUiThread(() -> {
                                toast("تم الحذف");
                                loadPath(currentPath);
                            });
                        } catch(Exception e) {
                            runOnUiThread(() -> toast("فشل الحذف: " + e.getMessage()));
                        } finally {
                            runOnUiThread(() -> setLoading(false));
                        }
                    });
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showCreateFileDialog() {
        final Dialog d = new Dialog(this);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(roundStroke(Color.rgb(10, 16, 30), 22, Color.rgb(44, 58, 92)));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView fileIcon = tv("＋", 17, Color.WHITE, true);
        fileIcon.setGravity(Gravity.CENTER);
        fileIcon.setBackground(round(accent, 12));
        head.addView(fileIcon, mp(dp(34), dp(34), 0, 0, 10, 0));

        LinearLayout headText = new LinearLayout(this);
        headText.setOrientation(LinearLayout.VERTICAL);
        headText.addView(tv("إنشاء ملف جديد", 14, Color.WHITE, true));
        headText.addView(tv("ملف جديد داخل المسار الحالي", 9, Color.rgb(150, 164, 192), false));
        head.addView(headText, new LinearLayout.LayoutParams(0, -2, 1));
        box.addView(head, mp(-1, -2, 0, 0, 0, 12));

        LinearLayout nameWrap = inputWithIcon("⌘");
        EditText name = (EditText) nameWrap.getChildAt(1);
        name.setHint("مثال: news.json");
        name.setTextSize(11);
        box.addView(nameWrap, mp(-1, dp(42), 0, 0, 0, 8));

        LinearLayout bodyWrap = inputWithIcon("≡");
        EditText body = (EditText) bodyWrap.getChildAt(1);
        body.setHint("المحتوى");
        body.setTextSize(11);
        body.setMinLines(3);
        body.setGravity(Gravity.TOP | Gravity.RIGHT);
        body.setPadding(dp(6), dp(8), dp(6), dp(8));
        box.addView(bodyWrap, mp(-1, dp(108), 0, 0, 0, 10));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setWeightSum(2f);

        TextView cancel = smallDialogBtn("إلغاء", Color.rgb(56, 66, 94), () -> d.dismiss());
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        cancelLp.setMargins(0, 0, dp(5), 0);
        actions.addView(cancel, cancelLp);

        TextView create = smallDialogBtn("إنشاء", accent, () -> {
            String fileName = name.getText().toString().trim();
            if (fileName.isEmpty()) {
                toast("اكتب اسم الملف");
                return;
            }
            String path = currentPath.isEmpty() ? fileName : currentPath + "/" + fileName;
            saveTextFile(path, "", body.getText().toString(), () -> {
                d.dismiss();
                loadPath(currentPath);
            });
        });
        LinearLayout.LayoutParams createLp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        createLp.setMargins(dp(5), 0, 0, 0);
        actions.addView(create, createLp);

        box.addView(actions);
        outer.addView(box);

        d.setContentView(outer);
        d.show();
        Window win = d.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.80f);
            win.setLayout(width, -2);
        }
    }

    private LinearLayout inputWithIcon(String iconText) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setPadding(dp(8), 0, dp(8), 0);
        wrap.setBackground(roundStroke(Color.rgb(8, 13, 25), 14, Color.rgb(55, 70, 108)));

        TextView icon = tv(iconText, 12, Color.rgb(0, 214, 255), true);
        icon.setGravity(Gravity.CENTER);
        wrap.addView(icon, mp(dp(22), dp(30), 0, 0, 5, 0));

        EditText e = new EditText(this);
        e.setSingleLine(false);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(156, 168, 195));
        e.setBackgroundColor(Color.TRANSPARENT);
        e.setPadding(dp(3), 0, dp(3), 0);
        e.setTextSize(11);
        wrap.addView(e, new LinearLayout.LayoutParams(0, -1, 1));
        return wrap;
    }

    private TextView smallDialogBtn(String s, int color, Runnable r) {
        TextView b = tv(s, 11, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackground(round(color, 12));
        b.setOnClickListener(v -> r.run());
        return b;
    }

    private TextView dialogBtn(String s, int color, Runnable r) {
        TextView b = tv(s, 11, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(round(color, 13));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1);
        lp.setMargins(dp(4), dp(2), dp(4), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private void applyMediumDialog(Dialog d, float widthPercent) {
        Window win = d.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(win.getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * widthPercent);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            win.setAttributes(lp);
        }
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null) uploadPicked(data.getData());
    }

    private void uploadPicked(Uri uri) {
        if (uri == null) return;
        setLoading(true);
        executor.execute(() -> {
            try {
                String fileName = queryName(uri);
                byte[] bytes = readAll(uri);
                String replacePath = getPreferences(0).getString("replace_path", "");
                String replaceSha = getPreferences(0).getString("replace_sha", "");
                boolean replacing = replacePath.length() > 0;
                String path = replacing ? replacePath : (currentPath.isEmpty() ? fileName : currentPath + "/" + fileName);

                JSONObject body = new JSONObject();
                body.put("message", (replacing ? "Replace " : "Upload ") + path + " from Hexor Admin");
                body.put("content", Base64.encodeToString(bytes, Base64.NO_WRAP));
                body.put("branch", BRANCH);
                if (replacing && replaceSha.length() > 0) body.put("sha", replaceSha);

                request("PUT", API_BASE + encodePath(path), body.toString());

                getPreferences(0).edit().remove("replace_path").remove("replace_sha").apply();
                runOnUiThread(() -> {
                    toast("تم رفع الملف");
                    loadPath(parentOf(path));
                });
            } catch(Exception e) {
                runOnUiThread(() -> toast("فشل الرفع: " + e.getMessage()));
            } finally {
                runOnUiThread(() -> setLoading(false));
            }
        });
    }

    private byte[] readAll(Uri uri) throws IOException {
        InputStream in = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    private String queryName(Uri uri) {
        String result = null;
        try {
            android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = c.getString(idx);
                c.close();
            }
        } catch(Exception ignored) {}
        if (result == null) result = "file_" + System.currentTimeMillis();
        return result;
    }

    private String request(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes(StandardCharsets.UTF_8));
            os.close();
        }
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String res = readString(is);
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " " + res);
        return res;
    }

    private String readString(InputStream is) throws IOException {
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        return sb.toString();
    }

    private String encodePath(String p) throws UnsupportedEncodingException {
        if (p == null || p.isEmpty()) return "";
        String[] parts = p.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<parts.length; i++) {
            if (i > 0) sb.append("/");
            sb.append(URLEncoder.encode(parts[i], "UTF-8").replace("+", "%20"));
        }
        return sb.toString();
    }

    private String parentOf(String p) {
        if (p == null || !p.contains("/")) return "";
        return p.substring(0, p.lastIndexOf('/'));
    }

    private void goBack() {
        if (!backStack.empty()) loadPath(backStack.pop());
        else if (!currentPath.isEmpty()) loadPath(parentOf(currentPath));
    }

    @Override
    public void onBackPressed() {
        if (!currentPath.isEmpty() || !backStack.empty()) goBack();
        else super.onBackPressed();
    }

    private void showEmpty(String msg) {
        content.removeAllViews();
        TextView e = tv(msg, 14, sub, false);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(10), dp(30), dp(10), dp(30));
        content.addView(e, mp(-1, -2, 0, 0, 0, 0));
    }

    private void setLoading(boolean show) {
        if (progress != null) progress.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private LinearLayout panel(int radius) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(roundStroke(card, radius, Color.rgb(40, 52, 82)));
        return l;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private TextView btn(String s, int color, Runnable r) {
        TextView b = tv(s, 12, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(round(color, 14));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1);
        lp.setMargins(dp(4), dp(3), dp(4), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(sub);
        e.setBackground(fieldBg());
        e.setPadding(dp(12), 0, dp(12), 0);
        return e;
    }

    private Drawable fieldBg() {
        return roundStroke(Color.rgb(9, 14, 27), 14, Color.rgb(52, 66, 100));
    }

    private Drawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private Drawable roundStroke(int color, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private Drawable makeGradient(int c1, int c2) {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{c1, c2});
    }

    private LinearLayout.LayoutParams mp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void copy(String s) {
        ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("link", s));
    }

    private void hideKeyboard() {
        try {
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(), 0);
        } catch(Exception ignored) {}
    }

    static class GitFile {
        String name, path, type, sha, downloadUrl;
        GitFile(String n, String p, String t, String s, String d) {
            name=n; path=p; type=t; sha=s; downloadUrl=d;
        }
    }
}
